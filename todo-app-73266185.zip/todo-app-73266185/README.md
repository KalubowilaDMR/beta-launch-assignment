Instruction for run the project

- You have V20.11 node version or later
- open the terminal and run command " yarn " to install yarn packages
- run comman " yarn run dev " to run the vite + react project
- let me know any trouble via " kalubowila.maneesha@gmail.com "
