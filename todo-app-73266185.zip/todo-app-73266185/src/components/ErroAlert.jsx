import { useState } from "react";
import { CloseIcon } from "../assets";

const ErrorAlert = ({ message, onClose }) => {
  const [isClose, setIsClose] = useState(false);

  const handleClose = () => {
    setIsClose(true);
    onClose();
  };
  console.log(isClose);

  return (
    <>
      {/* <div className="relative"> */}
      <div className="absolute bottom-10 right-10 w-[40%] bg-red-200 px-5 py-3">
        <div className="flex flex-row justify-between items-center">
          <p className="text-red-600">{message}</p>
          <div
            className="bg-white/30 p-1 border border-gray-400 cursor-pointer"
            onClick={handleClose}
          >
            <img src={CloseIcon} alt="Close" className="w-[25px] h-[25px]" />
          </div>
        </div>
      </div>
      {/* </div> */}
    </>
  );
};

export default ErrorAlert;
