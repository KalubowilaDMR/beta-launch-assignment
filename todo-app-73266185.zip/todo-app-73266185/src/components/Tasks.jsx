import { HighPrioritySVG, LowPrioritySVG, MediumPrioritySVG } from "../assets";
import { DoneLabel, InProgressLabel } from "./index";
import { TodoTasks } from "../context/TodoContext";
import ReactPaginate from "react-paginate";
import { useState } from "react";

const Tasks = () => {
  // destructure context data
  const { data, error } = TodoTasks();
  const [currentPage, setCurrentPage] = useState(0);

  const maxItemsPerPage = 8;
  const maxPageCount = data ? Math.ceil(data.length / maxItemsPerPage) : 0;

  console.log({ data, error });

  // change default dateTime to month-day
  const handleDateFormat = (dateTime) => {
    const date = new Date(dateTime);
    const monthsArray = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
    ];
    const month = monthsArray[date.getMonth()];
    const day = String(date.getDate()).padStart(2, "0");
    return `${month}-${day}`;
  };

  // page changing function
  const handlePageChange = ({ selected }) => {
    setCurrentPage(selected);
  };

  // data slicing to 8 items rendering
  const dataSlice = data?.slice(
    maxItemsPerPage * currentPage,
    maxItemsPerPage * (currentPage + 1)
  );

  return (
    <>
      {/* TODO section */}
      <div className="flex flex-row px-[16px] py-[12px] items-center">
        <p className="text-[16px] font-[500] text-[#000000]">Tasks</p>
      </div>

      {/* mark as done */}
      {dataSlice?.map((task) => (
        <div
          className="flex flex-row px-[16px] py-[14px] justify-between"
          key={task.id}
        >
          <div className="flex flex-row gap-[8px] items-start">
            <img
              src={
                task.priority === "HIGH"
                  ? HighPrioritySVG
                  : task.priority === "LOW"
                  ? LowPrioritySVG
                  : task.priority === "MEDIUM"
                  ? MediumPrioritySVG
                  : HighPrioritySVG
              }
              alt={task.priority}
              className="w-[20px] h-[20px]"
            />
            <div className="flex flex-col gap-[8px] items-start">
              <p className="text-[14px] font-[400] text-[#000000]">
                {task.todo}
              </p>
              {task.completed ? (
                ""
              ) : (
                <button className="text-[12px] font-[500] bg-transparent text-[#BC006D]">
                  Mark as done
                </button>
              )}
            </div>
          </div>
          <div className="flex flex-row gap-[14px] items-center">
            {task.completed ? (
              <DoneLabel>Done</DoneLabel>
            ) : (
              <InProgressLabel>In-Progress</InProgressLabel>
            )}
            <p className="text-[12px] font-[400] text-[#757575]">
              {handleDateFormat(task.createdAt)}
            </p>
          </div>
        </div>
      ))}

      {/* paginations */}
      <div className="flex flex-row gap-[16px] justify-center py-[27px]">
        <ReactPaginate
          previousLabel={"<"}
          nextLabel={">"}
          breakLabel={"..."}
          pageCount={maxPageCount}
          marginPagesDisplayed={2}
          onPageChange={handlePageChange}
          containerClassName="flex flex-row gap-[18px]"
          subContainerClassName="pages pagination"
          activeClassName="px-[12px] py-[5px] text-[#BC006D] rounded-[4px] border-2 border-[#BC006D] hover:border-2"
          pageClassName="px-[12px] py-[5px] rounded-[4px] border-2 hover:border-2"
          previousClassName="px-[12px] py-[5px] rounded-[4px] border border-[#EFEFEF] hover:border-2"
          nextClassName="px-[12px] py-[5px] rounded-[4px] border border-[#EFEFEF] hover:border-2"
        />
      </div>
    </>
  );
};

export default Tasks;
