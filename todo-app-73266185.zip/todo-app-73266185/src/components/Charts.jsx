import { TodoTasks } from "../context/TodoContext";
import { Doughnut } from "react-chartjs-2";
import { Chart as ChartJs, ArcElement, Tooltip, Legend } from "chart.js";
import { useEffect, useState } from "react";

ChartJs.register(ArcElement, Tooltip, Legend);

const Charts = () => {
  const { data, error } = TodoTasks();
  const [priorityChart, setpriorityChart] = useState(null);
  console.log("datafrom chart", data);

  useEffect(() => {
    if (Array.isArray(data) && data.length > 0) {
      const priorityCounts = data.reduce(
        (action, type) => {
          if (type.priority === "HIGH") action.High++;
          if (type.priority === "LOW") action.Low++;
          if (type.priority === "MEDIUM") action.Medium++;
          return action;
        },
        { High: 0, Low: 0, Medium: 0 }
      );

      const chart = {
        lables: ["High Priority", "Low Priority", "Medium Priority"],
        datasets: [
          {
            label: "Task by priority",
            data: [
              priorityCounts.High,
              priorityCounts.Low,
              priorityCounts.Medium,
            ],
            backgroundColor: ["#EB5757", "#2F80ED", "#F2C94C"],
            hoverBackgroundColor: ["#EB5757", "#2F80ED", "#F2C94C"],
          },
        ],
      };
      setpriorityChart(chart);
    }
  }, [data]);

  return (
    <>
      <div className="flex flex-col border bg-[#FFFFFF] border-[#D0D5DD] rounded-[8px] divide-y divide-[#D0D5DD] shadow-xl">
        <div className="flex flex-row px-[16px] py-[12px] items-center">
          <p className="text-[16px] font-[500] text-[#000000]">
            Tasks Positions
          </p>
        </div>
        {/* feed 01 */}
        <div className="flex flex-row px-[16px] py-[14px]">
          {/* chart data */}
          <div className="w-4/5">
            {priorityChart ? (
              <Doughnut data={priorityChart} />
            ) : (
              <p className="text-xl text-[#EB5757] font-[500]">Loding ...</p>
            )}
          </div>
          <div className="flex flex-col w-1/5 h-full pe-[16px] justify-center">
            <div className="flex flex-row gap-[12px] py-[16px]">
              <label className="p-3 rounded-full bg-[#EB5757]"></label>
              <span>High</span>
            </div>
            <div className="flex flex-row gap-[12px] py-[16px]">
              <label className="p-3 rounded-full bg-[#F2C94C]"></label>
              <span>Medium</span>
            </div>
            <div className="flex flex-row gap-[12px] py-[16px]">
              <label className="p-3 rounded-full bg-[#2F80ED]"></label>
              <span>Low</span>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Charts;
