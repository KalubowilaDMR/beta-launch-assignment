import styled from "styled-components";

// export const PriorityLabel = styled.label`
//   color : ${(props) => props.color || '#219653'};
//   background-color : ${(props) => props.bgColor || '#E8F5E9'};
//   font-size: 12px;
//   font-weight: 500;
//   padding: 2px 8px;
//   border-radius: 16px;
// `

export const DoneLabel = styled.label`
  color: #219653;
  background-color: #e8f5e9;
  font-size: 12px;
  font-weight: 500;
  padding: 2px 8px;
  border-radius: 16px;
`;

export const InProgressLabel = styled.label`
  color: #f2c94c;
  background-color: rgba(242, 201, 76, 0.1);
  font-size: 12px;
  font-weight: 500;
  padding: 2px 8px;
  border-radius: 16px;
`;
