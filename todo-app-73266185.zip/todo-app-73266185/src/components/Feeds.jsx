import { Avatar1, Avatar2 } from "../assets";

const Feeds = () => {
  return (
    <>
      <div className="flex flex-col border bg-[#FFFFFF] border-[#D0D5DD] rounded-[8px] divide-y divide-[#D0D5DD] shadow-xl">
        <div className="flex flex-row px-[16px] py-[12px] items-center">
          <p className="text-[16px] font-[500] text-[#000000]">Activity Feed</p>
        </div>
        {/* feed 01 */}
        <div className="flex flex-row px-[16px] py-[14px]">
          <div className="flex flex-row gap-[8px] items-start">
            <img
              src={Avatar1}
              alt="Feed Avatar"
              className="w-[32px] h-[32px]"
            />
            <div className="flex flex-col gap-[8px] items-start">
              <p className="text-[14px] font-[400] text-[#000000] leading-[24px]">
                <span className="font-[600]">Kushantha Charuka</span> created{" "}
                <span className="font-[600] text-[#BC006D]">
                  Contract #00124 need John Beige’s signature
                </span>
              </p>
              <label className="text-[12px] font-[400] bg-transparent text-[#757575]">
                Sep 16, 2022 at 11:30 AM
              </label>
            </div>
          </div>
        </div>
        {/* feed 02 */}
        <div className="flex flex-row px-[16px] py-[14px]">
          <div className="flex flex-row gap-[8px] items-start">
            <img
              src={Avatar2}
              alt="Feed Avatar 02"
              className="w-[32px] h-[32px]"
            />
            <div className="flex flex-col gap-[8px] items-start">
              <p className="text-[14px] font-[400] text-[#000000] leading-[24px]">
                Lorem ipsum <span className="font-[600]">dolor sit amet,</span>{" "}
                consectetur adipiscing elit.{" "}
                <span className="font-[600]">Maecenas</span> pretium neque
              </p>
              <label className="text-[12px] font-[400] bg-transparent text-[#757575]">
                Sep 16, 2022 at 11:45 AM
              </label>
            </div>
          </div>
        </div>
        {/* feed 03 */}
        <div className="flex flex-row px-[16px] py-[14px]">
          <div className="flex flex-row gap-[8px] items-start">
            <img
              src={Avatar2}
              alt="Feed Avatar 02"
              className="w-[32px] h-[32px]"
            />
            <div className="flex flex-col gap-[8px] items-start">
              <p className="text-[14px] font-[400] text-[#000000] leading-[24px]">
                Lorem ipsum <span className="font-[600]">dolor sit amet,</span>{" "}
                consectetur adipiscing elit.{" "}
                <span className="font-[600]">Maecenas</span> pretium neque
              </p>
              <label className="text-[12px] font-[400] bg-transparent text-[#757575]">
                Sep 16, 2022 at 11:45 AM
              </label>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Feeds;
