import Tasks from "./Tasks";
import Feeds from "./Feeds";
import Charts from "./Charts";
import ErrorAlert from "./ErroAlert";
import { DoneLabel, InProgressLabel } from "./styled-components/Label";

export { Tasks, Feeds, Charts, ErrorAlert, DoneLabel, InProgressLabel };
