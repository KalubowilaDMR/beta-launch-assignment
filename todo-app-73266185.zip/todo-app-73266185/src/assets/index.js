import HighPrioritySVG from "./Priority-High.svg";
import LowPrioritySVG from "./Priority-Low.svg";
import MediumPrioritySVG from "./Priority-Medium.svg";
import DashboardSVG from "./Dashboard.svg";
import ProfileSVG from "./Profile.svg";
import NotificationSVG from "./Notifications.svg";
import DownChewronSVG from "./Chevron-down.svg";
import Avatar1 from "./Avatar-1.svg";
import Avatar2 from "./Avatar-2.svg";
import CloseIcon from "./Close.svg";
import VectorSvg from "./Vector.svg";

export {
  HighPrioritySVG,
  LowPrioritySVG,
  MediumPrioritySVG,
  DashboardSVG,
  ProfileSVG,
  NotificationSVG,
  DownChewronSVG,
  Avatar1,
  Avatar2,
  CloseIcon,
  VectorSvg,
};
