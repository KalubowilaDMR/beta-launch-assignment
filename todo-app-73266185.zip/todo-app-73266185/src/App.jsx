import Dashboard from "./pages/Dashboard";
import "./App.css";
import TodoTasksProvider from "./context/TasksProvider";

function App() {
  return (
    <>
      {/* provider pass data to childrens to access */}
      <TodoTasksProvider>
        <Dashboard />
      </TodoTasksProvider>
    </>
  );
}

export default App;
