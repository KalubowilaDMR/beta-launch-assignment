import { useState, useEffect } from "react";
import axios from "axios";
import TodoContext from "./TodoContext";

const TodoTasksProvider = ({ children }) => {
  const [data, setData] = useState();
  const [error, setError] = useState();

  const API_ENDPOINT = "https://6363c8f68a3337d9a2e7d805.mockapi.io/api/to-do";

  useEffect(() => {
    fetchTodoData();
    // fetching data every minutes
    const interval = setInterval(fetchTodoData, 60000);
    return () => clearInterval(interval);
  }, []);

  // fetching todo data from api endpoint
  const fetchTodoData = async () => {
    try {
      const response = await axios.get(API_ENDPOINT);
      setData(response.data);
      console.log(response);
    } catch (error) {
      setError(error);
      console.log(error);
    }
  };

  return (
    // passthe fetching data to provider
    <TodoContext.Provider value={{ data, error }}>
      {children}
    </TodoContext.Provider>
  );
};

export default TodoTasksProvider;
