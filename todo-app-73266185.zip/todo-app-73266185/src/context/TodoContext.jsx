import { createContext, useContext } from "react";

const TodoContext = createContext();

export const TodoTasks = () => {
  return useContext(TodoContext);
};

export default TodoContext;
