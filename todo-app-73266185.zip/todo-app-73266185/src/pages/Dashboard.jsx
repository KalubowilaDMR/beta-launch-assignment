import { useEffect, useState } from "react";
import {
  DashboardSVG,
  ProfileSVG,
  NotificationSVG,
  DownChewronSVG,
  CloseIcon,
  VectorSvg,
} from "../assets";
import { Tasks, Feeds, Charts, ErrorAlert } from "../components";
import { TodoTasks } from "../context/TodoContext";

const Dashboard = () => {
  const { error } = TodoTasks();
  const [isClose, setIsClose] = useState(false);
  const [errorClose, setErrorClose] = useState(false);

  useEffect(() => {
    if (error) setErrorClose(false);
  }, [error]);

  const handleErrorClose = () => {
    setErrorClose(true);
  };

  return (
    <>
      <div className="flex flex-row w-full h-screen">
        {!errorClose && (
          <ErrorAlert message={error} onClose={handleErrorClose} />
        )}
        {/* sidebar  */}
        <div className="flex flex-col fixed top-0 left-0 h-[100vh] w-[15%] md:w-[20%] lg:w-[15%] bg-[#33074F]">
          <div className="flex w-full bg-[#EBE6ED] bg-opacity-10 px-[45px] py-[24px] justify-center">
            <p className="text-[12px] md:text-[16px] lg:text-[24px] text-[#FFFFFF] font-[600] font-[inter] text-center">
              Acmy Solutions
            </p>
          </div>
          <div className="flex flex-row gap-3 w-[80%] bg-[#EBE6ED] bg-opacity-10 hover:bg-opacity-25 mx-auto px-[16px] py-[11px] rounded-[24px] mt-[60px] items-center justify-center">
            <img
              src={DashboardSVG}
              alt="Dashboard"
              className="w-[24px] h-[24px]"
            />
            <p className="text-white text-[16px] font-[400] hidden lg:block">
              Dashboard
            </p>
          </div>
        </div>
        {/* content */}
        <div className="flex flex-col gap-[24px] w-[85%] h-[100vh] lg:ml-[15%] ml-[15%] md:ml-[20%] bg-[#FAFAFA]">
          {/* Header section */}
          <section className="flex flex-row w-full justify-between items-center p-[24px] bg-[#FFFFFF] shadow-md">
            <h2 className="text-[20px] text-[#000000] font-[600]">Dashboard</h2>
            <div className="flex flex-row gap-2 items-center">
              <img
                src={NotificationSVG}
                alt="Notifications"
                className="h-[24px] w-[24px] me-4"
              />
              <img
                src={ProfileSVG}
                alt="ProfileSVG"
                className="h-[40px] w-[40px]"
              />
              <img
                src={DownChewronSVG}
                alt="DownChewronSVG"
                className="h-[24px] w-[24px]"
              />
            </div>
          </section>
          <div className="px-[24px]">
            {/* Welcom section */}
            {isClose ? (
              ""
            ) : (
              <section
                className="flex flex-col w-full gap-[4px] px-[16px] py-[18px] bg-[#FFFFFF] border border-[#D0D5DD] rounded-[8px] relative shadow-lg"
                style={{
                  background: `url(${VectorSvg}) no-repeat calc(100% - 10%) 0 / auto 100%`,
                }}
              >
                <img
                  src={CloseIcon}
                  alt="closeIcon"
                  className="absolute right-3 top-3 float-right w-[25px] h-[25px] cursor-pointer"
                  onClick={() => setIsClose(true)}
                />
                <h3 className="text-[24px] text-[600] text-[#000000]">
                  Welcom back, Jhone Doe
                </h3>
                <p className="text-[14px] text-[400] text-[#757575]">
                  The end of the year is coming. Are you planning your
                  performance interviews? You can do this super efficiently with
                  Acmy. Look here for more information
                </p>
                <a className="text-[14px] text-[400] text-[#BC006D]">
                  Look here for more information
                </a>
              </section>
            )}
          </div>
          <div className="flex flex-col lg:flex-row w-full gap-[24px] px-[24px]  pb-[24px]">
            {/* Left side */}
            <div className="flex flex-col w-full h-fit lg:w-3/5 border bg-[#FFFFFF] border-[#D0D5DD] rounded-[8px]  divide-y divide-[#D0D5DD] shadow-2xl">
              <Tasks />
            </div>
            {/* Right side */}
            <div className="flex flex-col gap-[16px] w-full lg:w-2/5">
              {/* FEED section */}
              <Feeds />
              {/* Charts section */}
              <Charts />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Dashboard;
